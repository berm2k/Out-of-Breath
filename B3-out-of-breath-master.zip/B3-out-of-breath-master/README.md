To install This Script لتنزيل و تفعيل هذا السكربت

1 - Unzip this file فك ضغط الملف
2 - Drag it in resourse folder انسخة الى ملف الريسورس
3 - start from cfg تشغيل كوماند تفعيل السكربت من ال سي اف جي
